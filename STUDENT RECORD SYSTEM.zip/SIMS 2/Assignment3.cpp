#include<iostream>
#include<cstring>
#include<math.h>
using namespace std;
class Shape2D{
    char name[20];
    double area;
public:
    Shape2D(char *s,double area)
    {
        strcpy(name,s);
        this-> area=area;

    }

char *getName(){return name;}
double getarea() {return area;}

    };


class Shape3D{
    char name[20];
    double volume;
public:
   Shape3D(char *s,double volume)
   {
       strcpy(name,s);
        this-> volume=volume;
    }
    double getVolume(){return volume;}

    char *getName()
    {return name;}
    };



    class Circle: public Shape2D{
        double radius;
          char name2;
  public:
      Circle (char *name,double radius):Shape2D(name,radius)
      {
       name2=*name;
    this->radius=radius;

     }
double calcArea()
{
    return radius*radius*3.1416;
}

    void showArea()
    {
   cout<<getName()<<' '<<calcArea()<<endl;

    }};

class Rectangle{
    double h,w;
public:
    Rectangle(double h,double w)
    {
        this->h=h;
        this->w=w;
    }
    double calcArea()
    {return h*w;}
    void showArea()
    {
    cout<<"Rectangle:"<<calcArea()<<endl;
    }};





class Box{
  double h,w,l;
  public:
      Box(double h,double w,double l)
      {
          this ->h=h;
          this ->w=w;
          this ->l=l;
      }
      double calcVolume()
    {
      return h*w*l;
    }
    void showVolume()
    {
      cout<<"Box:"<<calcVolume()<<endl;
    }
     };

class Sphere:public Shape3D{
  double radius;
   char name2;
  public:
 Sphere(char *name,double radius):Shape3D(name,radius)
      {
       name2=*name;
    this->radius=radius;

  }
      double calcVolume()
    {
    return 1.333*3.1416*pow(radius,3);
    }
    void showVolume()
    {cout<<getName()<<' '<<calcVolume()<<endl; }
    };
int main()
{
    Circle c("Circle",2.5);   //Circle (Char *name, double radius);
    Box b(4,5,10);            //Box(double h,double w,double l);
    Sphere s("Sphere",5.6);    //Sphere(char *name,double radius);
    Rectangle r(4,100);         // Rectangle(double h,double w);
    c.showArea();
    b.showVolume();
    s.showVolume();
    r.showArea();



return 0;
}
