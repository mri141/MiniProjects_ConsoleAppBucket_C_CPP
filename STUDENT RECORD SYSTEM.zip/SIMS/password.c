#include <stdio.h>
#include <stdlib.h>

 admininfo(){

char UserName[] = "Admin";
scanf("%s", &UserName);
printf("Please enter your password: \n");
char PassWord[] = "Chocolate";
scanf("%s", &PassWord);

    if (UserName == "Admin")
    {
     if (PassWord == "Chocolate"){
     printf("Welcome!\n");
    }
    }else
    {
     printf("The user name or password you entered is invalid.\n");
    }
    }


    userinfo(){
        char UserName[50];
scanf("%s", &UserName);
printf("Please enter your password: \n");
char PassWord[] = "pass";
scanf("%s", &PassWord);

     if (PassWord == "pass"){
     printf("Welcome!\n");
    }
    else
    {
     printf("The user password you entered is invalid.\n");
    }
    }


int main()
{
    char a;
    printf("Enter A for Admin Access \nEnter C for Client Access\n");
    scanf("%c",&a);
    if(a='A'){
         admininfo();
    }
    else if(a='C'){
         userinfo();
        }
        else
            printf("incorrect");

          return 0;
}
