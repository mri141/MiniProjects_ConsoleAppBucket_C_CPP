#include <stdio.h>

void main()
{
  for(;;){
    int vectorx[] = {1,2,3,4,5,6,7,8,9,10};
    int i, n, pos, element, found = 0,option;


    printf("\t\t\t\t===============Bus Ticket Booking===============\n\n\n");
    printf("1. Total Seat\n2. Purchase A Seat\n3. Quit\n\n");
    printf("Choose an Option\n\n");
    scanf("%d",&option);

    if(option == 1){
        printf("Total Seat Are: ");
        for (i = 0; i < 10; i++)
        {
            printf("%d\t", vectorx[i]);
        }
    }

    if(option==2){
        printf("Please select your seat: ");
        scanf("%d", &element);
        printf("\n\n You have successfully purchased your desirable seat\n\n");
        for (i = 0; i < 10; i++)
        {
            if (vectorx[i] == element)
            {
                found = 1;
                pos = i;
                break;
            }
        }

        if (found == 1)
        {
            for (i = pos; i <  10 - 1; i++)
            {
                vectorx[i] = vectorx[i + 1];
            }
            printf("Avaliable seats are: \n");
            for (i = 0; i < 10 - 1; i++)
            {
                printf("%d\t", vectorx[i]);
            }
        }
        else
            printf("Element %d is not found in the vector\n", element);
    }

    if(option == 3){
        goto exit;
    }
    printf("\n\n");
    exit:
        printf("Thank you for being with us.\n\n");
    }
    return 0;
}
