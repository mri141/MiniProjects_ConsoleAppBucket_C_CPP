#include<stdio.h>

void main()
{
    int vectorx[] = {1,2,3,4,5,6,7,8,9,10};
    int i, n, pos, element, found = 0,time;
    float option;
    char el;

    printf("\t\t\t\t===============Bus Ticket Booking===============\n\n\n");
    printf ("\t\t\t\t\tWelcome to Our Bus Service\n\n");
    printf ("Bus Destination:\n\n\n");
    printf("1. Dhaka to Cox'sbazar\n2. Dhaka to Rajshahi\n3. Dhaka to Khulna");
   // printf("1. Total Seat\n2. Purchase A Seat\n3. Quit\n\n");
    printf("Where you want to visit???\n\n");
    scanf("%d",&option);

    if(option == 1){
        printf("1.07:00 PM\n2.08:00 PM\n3.09:00 PM\n");
        printf("When you want to visit???\n");
        if(option == 1.1){
            printf("1.Total Seat\n2.Purchased A Seat\n3.Quit\n");


                if(option == 4){
        printf("Total Seats Are: ");
        for (i = 0; i < 10; i++)
        {
            printf("%d\t", vectorx[i]);
        }
    }

    if(option==2){
        printf("Please select your seat: ");
        scanf("%d", &element);
         scanf("%c", &el);


        char name[100],a[10],c[100];
    int price,trivilingtime,counterno,i;
    FILE *fread, *fwrite;
    fread = fopen("write.txt","w");


        printf("\n Enter Name: ");
        gets(name);
        printf("\n Ticket price: ");
        scanf("%d",&price);
        printf("\n Enter traveling time: ");
        scanf("%d",&trivilingtime);
        printf("\n Enter counter no: ");
        scanf("%d",&counterno);
        scanf("%c",&a);

        fprintf(fread,"%s\n%d\n%d\n%d\n",name,price,trivilingtime,counterno);

    fclose(fread);
    fread = fopen("write.txt","r");
    i = 1;
    while (fgets(c,sizeof(c),fread)){
        if(i == 5)
        {
            i = 1;
        }
        if(i == 1)
        {
            printf("Name: ");
        }
        if(i == 2)
        {
            printf("Price: ");
        }
        if(i == 3)
        {
            printf("Traveling time: ");
        }
        if(i == 4)
        {
            printf("price: ");
        }
        printf("%s", c);
        i++;
    }


        printf("\n\n You have successfully purchased your suitable seat\n\n");
        for (i = 0; i < 10; i++)
        {
            if (vectorx[i] == element)
            {
                found = 1;
                pos = i;
                break;
            }
        }

        if (found == 1)
        {
            for (i = pos; i <  10 - 1; i++)
            {
                vectorx[i] = vectorx[i + 1];
            }
            printf("Available seats are: \n");
            for (i = 0; i < 10 - 1; i++)
            {
                printf("%d\t", vectorx[i]);
            }
        }
        else
            printf("Element %d is not found in the vector\n", element);
    }

    if(option == 3){
        goto exit;
    }
    printf("\n\n");
    exit:
        printf("Thank you for being with us.\n\n");


        }
    }
    return 0;
}
